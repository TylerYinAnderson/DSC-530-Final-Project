from .thinkstats2 import *
